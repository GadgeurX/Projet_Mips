/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-4
  * fractale.h
  * Eva Gerbert-Gaillard
  */

#ifndef __FRACTALE_H__
#define __FRACTALE_H__

#include <stdio.h>
#include <math.h>
#include "graphlib.h"

/*constantes publiques*/
#define G_MAX_RANG 9

/*prototypes publiques*/
void g_fractale (int n, int anim);

#endif
