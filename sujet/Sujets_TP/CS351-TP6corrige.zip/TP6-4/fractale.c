/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-4
  * fractale.c
  * Eva Gerbert-Gaillard
  */

#include "fractale.h"


/*constantes privées*/
#define UNIT 50
#define INIT 500
#define LARG 800
#define HAUT 600
#define OFFSET_X (LARG - INIT)/2
#define OFFSET_Y (HAUT - INIT)/2

#define TITRE "TP7 - Triangle de Sierpinsky"
#define NO_DISK 0

/*prototypes privés*/
void dessineCarrePlein(double posx, double posy, double tx, double ty);
void fractale(int rang, double x, double y, int n, int anim);


/*initialisation*/
void g_fractale (int n, int anim) {
	
	
	gr_inits_w(LARG, HAUT, TITRE);
	set_black();
	dessineCarrePlein(OFFSET_X, OFFSET_Y, INIT, INIT);
	set_yellow(); /*il n'y a pas de set_white()*/
	fractale(1, 1, 1, n, anim);
	
	point(-1,-1); /*Instruction graphique nulle a cause de problemes d'affichage*/
	cliquer();	/*Attente d'un clique*/
}

/*fractale recursive*/
void fractale(int rang, double x, double y, int n, int anim){
	double div = INIT/pow(2,rang);

	dessineCarrePlein(OFFSET_X + div*x, OFFSET_Y + div*y, div, div);

	point(-1,-1); /*Instruction graphique nulle a cause de problemes d'affichage*/
	if(anim == 1){
		cliquer();	/*Attente d'un clique, animation step by step*/
	}

	if(rang<n){
		rang++;
		fractale(rang, x, y, n, anim);
		fractale(rang, x+pow(2,rang-1), y, n, anim);
		fractale(rang, x, y+pow(2,rang-1), n, anim);
	} 
}

void dessineCarrePlein(double posx, double posy, double tx, double ty){
	/*fill_triangle -> coordonnees de 3 points*/
	/*2 triangles pour faire un carré*/
	fill_triangle(posx+tx, posy, posx, posy+ty, posx, posy);
	fill_triangle(posx+tx, posy, posx, posy+ty, posx+tx, posy+ty);
}

