/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-4
  * main.c
  * Eva Gerbert-Gaillard
  */
  
#include <stdio.h>
#include "fractale.h"
  

int main(int argc, char * argv[]){

	int n = 0;
	int animOpt = 0;
	
	printf("TRIANGLE DE SIERPINSKI - ");
	printf("Entrez le rang: ");
	scanf("%d", &n);
	if(n<0) n=0; /*Si n trop petit*/
	if(n>G_MAX_RANG) n=G_MAX_RANG; /*Si n trop grand pour l'affichage*/
	
	printf("Voulez-vous suivre l'animation pas à pas? (0=non/1=oui): ");
	scanf("%d", &animOpt);
	printf("\n");

	g_fractale(n, animOpt);

	return 0;
}
