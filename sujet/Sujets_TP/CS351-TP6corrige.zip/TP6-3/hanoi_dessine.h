/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-3
  * hanoi_dessine.h
  * Eva Gerbert-Gaillard
  */

#ifndef __HANOI_DESSINE_H__
#define __HANOI_DESSINE_H__

#include <stdio.h>
#include "graphlib.h"

/*constantes publiques*/
#define G_MAX_DISK 10
#define tagA 'A'
#define tagB 'B'
#define tagC 'C'

/*prototypes publiques*/
void g_initTours(int n, char A, char B, char C);
void g_deplacerDisque(char from, char to);

#endif
