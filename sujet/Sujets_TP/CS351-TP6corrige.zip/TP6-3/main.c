/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-3
  * main.c
  * Eva Gerbert-Gaillard
  */

#include <stdio.h>
#include <stdlib.h>

#include "hanoi_dessine.h"

int grapOpt = 0;
void hanoi (int n, char A, char B, char C);
void deplacementHanoi(char A, char C);


int main(int argc, char * argv[]){
	int n;
	printf("TOUR DE HANOI - ");
	printf("Entrez le nombre de disques de depart sur A: ");
	scanf("%d", &n);
	if(n<1) n=1; /*Si n trop petit*/
	printf("Voulez-vous un affichage graphique? (0=non/1=oui): ");
	scanf("%d", &grapOpt);
	printf("\n");
	if(grapOpt == 1){
		if(n>G_MAX_DISK) n=G_MAX_DISK; /*Si n trop grand pour l'affichage*/
		g_initTours(n, tagA, tagB, tagC);
	}
	hanoi(n, tagA, tagB, tagC);

	return 0;
}

/*Affichage du déplacement de disques Hanoi*/
void deplacementHanoi(char A, char C){
	if(grapOpt == 1){
		g_deplacerDisque(A, C);
	} else {
		printf("%c vers %c\n",A, C);	
	}
}

/*Hanoi recursif*/
void hanoi (int n, char A, char B, char C) {
	if (n == 1) {
		deplacementHanoi(A, C);
	} else {
		hanoi(n-1, A, C, B);
		hanoi(1, A, B, C);
		hanoi(n-1, B, A, C);
	}
}


