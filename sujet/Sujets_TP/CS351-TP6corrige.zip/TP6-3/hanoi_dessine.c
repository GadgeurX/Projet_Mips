/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-3
  * hanoi_dessine.c
  * Eva Gerbert-Gaillard
  */
  
#include "hanoi_dessine.h"

/*constantes privées*/
#define UNIT_X 250
#define UNIT_Y 25
#define OFFSET_X (25+UNIT_X/2)
#define OFFSET_Y 0 
#define LARG 800
#define HAUT 600

#define TITRE "TP7 - Tours de Hanoi"
#define NO_DISK 0

/*variables globales privées*/
int tA[G_MAX_DISK];
int tB[G_MAX_DISK];
int tC[G_MAX_DISK];

/*prototypes privés*/
int* selectTabTour (char tagT);
void initTabTours(int n);
void refreshAffichage();
void dessineDisque(char tagT, int pos, int taille);
void dessineRectangle(int posx, int posy, int tx, int ty);

/*Initialisation graphique pour les tours de Hanoi*/
void g_initTours(int n, char A, char B, char C){
	initTabTours(n);
	gr_inits_w(LARG, HAUT, TITRE);
	cliquer();	/*Pour éviter un bug d'affichage*/
	refreshAffichage();
}

void g_deplacerDisque(char from, char to){
	
	int i=0;
	int j=0;
	int* f;
	int* t;
	f = selectTabTour(from);
	t = selectTabTour(to);

	while((f[i] != NO_DISK)&&(i<G_MAX_DISK)) i++;	/*Dernier emplacement occupé*/
	while((t[j] != NO_DISK)&&(j<G_MAX_DISK-1)) j++;	/*Premier emplacement inoccupé, ou dernier emplacement*/
	t[j] = f[i-1];		/*Deplacement*/
	f[i-1] = NO_DISK;
	
	refreshAffichage();
}

/*Selection du tableau correspondant à la lettre entrée en paramètre*/
int* selectTabTour (char tagT){
	int* t;
	switch(tagT){
		case tagA :
			t = &tA[0];
			break;
		case tagB :
			t = &tB[0];
			break;
		case tagC :
			t = &tC[0];
			break;
	}
	return t;
}

/*Initialisation des tableaux représentant les tours*/
void initTabTours(int n){
	int i;
	for(i=0; i<G_MAX_DISK; i++){
		if (n>0){
			tA[i] = n--;
		} else {
			tA[i] = NO_DISK;
		} 
		tB[i] = NO_DISK; 
		tC[i] = NO_DISK;
	}
}

/*Rafraichissement de l'affichage*/
void refreshAffichage(){
	/*Ce n'est pas très optimisé car l'affichage se refait entièrement à chaque fois, mais c'est plsu facile à gérer que d'effacer*/
	int i;

	clear_screen();
	for(i=0; i<G_MAX_DISK; i++){
		dessineDisque(tagA, i, tA[i]);
		dessineDisque(tagB, i, tB[i]);
		dessineDisque(tagC, i, tC[i]);
	}
	point(-1,-1); /*Instruction graphique nulle a cause de problemes d'affichage*/
	cliquer(); /*Attente d'interaction utilisateur, pour visualiser les étapes*/
}

/*Dessiner un disque sur une tour*/
void dessineDisque(char tagT, int pos, int taille){
	int posx, posy, tx, ty;
	tx = UNIT_Y*taille;
	ty = UNIT_Y;
	posy = OFFSET_Y + UNIT_Y*pos;
	
	switch(tagT){
		case tagA :
			posx = OFFSET_X + UNIT_X*0;
			break; 
		case tagB :
			posx = OFFSET_X + UNIT_X*1;
			break;
		case tagC :
			posx = OFFSET_X + UNIT_X*2;
			break;
	}
	
	dessineRectangle(posx, HAUT - posy, tx, -ty);  /*Inversion de l'axe Y, car sur la fenêtre X> et Y^*/
}

/*Dessiner un rectangle, autour d'un axe*/
void dessineRectangle(int posx, int posy, int tx, int ty){
	line(posx - tx/2, posy, posx + tx/2, posy);
	line(posx + tx/2, posy, posx + tx/2 , posy + ty);
	line(posx + tx/2, posy + ty, posx - tx/2, posy + ty);
	line(posx - tx/2, posy + ty, posx - tx/2, posy);
}


