/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-2
  * fctDiv.h
  * Eva Gerbert-Gaillard
  */
  

#ifndef __FCTDIV_H__
#define __FCTDIV_H__

#include <stdio.h>
#include <stdlib.h>


int fibonacci (int n);
int pgcd (int a, int b);
int palindrome (char mot[], int d, int f);

#endif
