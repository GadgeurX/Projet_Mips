/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-2
  * main.c
  * Eva Gerbert-Gaillard
  */
  
#include <stdio.h>
#include <stdlib.h>

#include "fctDiv.h"

int compterCaracteres(char mot[]);

int main()
{
	int choix = 1;
	int a, b;
	char mot [20];

	/* test switch pour pouvoir facilement tout tester */
	do {
		printf("Bienvenue dans le programme de recursivite.\nPour quitter : Entrez 0\nFibonacci : Entrez 1\nPGCD : Entrez 2\nPalindrome : Entrez 3\nChoix : ");
		scanf("%d", &choix);
		switch (choix) {
			case 1 : printf("FIBONACCI - Entrez le rang : ");
				scanf("%d", &a);
				printf("L'element au rang %d de fibonacci est : %d", a, fibonacci(a));
				break;
			case 2 : 
				printf("PGCD - Entrez a et b : \n");
				scanf("%d", &a);
				scanf("%d", &b);
				printf("Le pgcd de %d et %d vaut : %d", a, b, pgcd(a, b));
				break;
			case 3 : 
				printf("PALINDROME - Entrez un mot de moins de 20 caracteres : ");
				scanf("%s", mot);
				if (palindrome(mot, 0, compterCaracteres(mot)-1)) {
					printf("\n \"%s\" est un palindrome", mot);
				} else {
					printf("\n \"%s\" n'est pas un palindrome", mot);
				}
				break;
			default : choix = 0;
		}
		printf("\n\n");
	}
	while (choix !=0);
	

	return 0;
}

int compterCaracteres(char mot[]){
	int i = 0;
	
	while(mot[i] != '\0'){
		i++;
	}
	return i;
}
