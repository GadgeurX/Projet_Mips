/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP7-2
  * fctDiv.c
  * Eva Gerbert-Gaillard
  */

#include "fctDiv.h"

int fibonacci (int n) {
	if (n > 1) {
		n = fibonacci(n-2) + fibonacci(n-1);
	}
	return n;
}


int pgcd (int a, int b) {
	if (b == 0) {
		return a;
	} else {
		return pgcd(b, a%b);
	}
}
/*int pgcd (int a, int b) {
	int r;

	while (b !=0) {
		r = a%b;
		a = b;
		b = r;
	}
	return a;
}*/

int palindrome (char mot[], int deb, int fin){
	return((deb >= fin) || (mot[deb] == mot[fin]) && (palindrome(mot, deb+1, fin-1)));
}
