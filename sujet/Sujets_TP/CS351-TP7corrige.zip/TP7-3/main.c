/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP8-3
  * main.c
  * Eva Gerbert-Gaillard
  */

#include <stdio.h>
#include <stdlib.h>

#include "drap.h"



int main (){

	int *drap = NULL;
	int tab[20];	/*Allocation de mémoire au prochain TP*/
	/*int tab_ex[] = { 5, 8, 1, 4, 3, 9, 2, 7, 3, 8, 1, 4, 5, 3, 8 };*/
    int tab_ex[] = { 8, 8, 1, 4, 3, 9, 2, 7, 3, 8, 1, 4, 5, 3, 2 };

	int N = 15;
	int opt=0;
	int i;

	printf("DRAPEAU HOLLANDAIS - ");
	printf("\nVoulez-vous utiliser un tableau pre-rempli (0=non, 1=oui):");
	scanf("%d", &opt);
	if(opt==1){
		drap = &tab_ex[0];
	} else {
		drap = &tab[0];
		printf("Entrez la taille du tableau (max 20): ");
		scanf("%d", &N);
		if(N<1) N=1;
		if(N>20) N=20;
		printf("\nEntrez les valeurs (entre 0 et 9): ");
		for (i=0; i<N; i++) {
			scanf("%d", drap+i);
			if(*(drap+i)<0) *(drap+i)=0;
			if(*(drap+i)>9) *(drap+i)=9;
		}
	}

	triDrap(drap, N);
	printf("\nVoici le tableau trie :\n");
	for (i=0; i<N; i++) {
		printf("%d\t", *(drap+i));
	}
	printf("\n");

	return 0;
}
