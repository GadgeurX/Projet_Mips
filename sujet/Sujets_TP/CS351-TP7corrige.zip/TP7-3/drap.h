/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP8-3
  * drap.h
  * Eva Gerbert-Gaillard
  */
  

#ifndef __DRAP_H__
#define __DRAP_H__

#include <stdlib.h>
#include <stdio.h>


/*prototypes*/
void triDrap (int* drap, int N);

#endif
