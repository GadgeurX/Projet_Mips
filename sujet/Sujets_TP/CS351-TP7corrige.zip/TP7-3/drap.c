/**
  */

#include "drap.h"

void triDrap (int* drap, int N){
	int *b = drap; /*&tab[0];*/
	int *w = drap;/*&tab[N-1];*/
	int *r = drap+N-1;/*&tab[N-1];*/
	int k; /*variable intermediaire*/

	while (w <= r) {
		if ((*w >= 3) && (*w <= 6)) w = w +1;
		else if (*w < 3) {
			k = *b;
			*b = *w;
			*w = k;
			b++; w++;
		} else {
			k = *w;
			*w = *r;
			*r = k;
			r--;
		}
	}

}
