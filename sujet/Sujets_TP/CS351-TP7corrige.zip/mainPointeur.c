#include <stdlib.h>
#include <stdio.h>

#define TRACE printf("a=%d,b=%d,c=%d,&a=%x,&b=%x,&c=%x,p1=%x,p2=%x,*p1=%d,*p2=%d\n", a, b, c, &a, &b, &c, p1, p2, *p1, *p2); getchar();


int main(int argc, char * argv[]) {

	int a, b, c;
	int *p1, *p2;

	/* Initialisation des variables */
	a = 2;
	b = 5;
	c = 3;

	/* Manipulation des pointeurs */
	p1 = &a; TRACE;
	p2 = &b; TRACE;

	*p1 = *p2; TRACE;

	(*p2)++; TRACE;

	p1 = p2; TRACE;
	p2 = &c; TRACE;

	*p2 = *p1 - 2 * *p2; TRACE;
	(*p2)--; TRACE;
	*p1 = *p2 - b; TRACE;

	a = (2 + *p2) * *p1; TRACE;
	p2 = &b; TRACE;

	*p2 = *p1 / *p2; TRACE;
	*p1 = a + c; TRACE;

	a += *p1; TRACE;
	c = *p1 + *p2; TRACE;

	*p1 = 2 * a; TRACE;

	a = *p2; TRACE;

	*p2 = *p1 - *p2; TRACE;
	*p1 = 1 - b; TRACE;
	*p2 += *p1 + a; TRACE;

	p2 = p1 = &a; TRACE;
	p2++; TRACE;
	p1 += 2; TRACE;
	b = p2 == &c; TRACE;

	p1 = NULL;
	return 0;
}
