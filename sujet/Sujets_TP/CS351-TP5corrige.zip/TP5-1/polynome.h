#define DEGREMAX 100
typedef struct{
    float coeff;
    int degre;
} Terme;

typedef Terme Polynome[DEGREMAX];

