#ifndef charToHexa_H_
#define charToHexa_H_

void charToHexa( InstructionBrut instruction[]);//Fonction de redirection
void convertionInstructionTypeJ (char* instruction, char* operande1);
char* convertionInstructionTypeI (char* instruction, char* operande1, char* operande2);
char* convertionInstructionTypeR (char* instruction, char* operande1, char* operande2, char* operande3);


#endif
